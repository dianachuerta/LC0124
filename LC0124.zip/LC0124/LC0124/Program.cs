﻿// MIS 3033 001
// Jan 24, 2024
// Diana Huerta
// 113553066

// loops
// for loop
// while loop
// break continue
// break: stop the loop
// continue 
for (int i = 50; i <= 100; i = i + 1)
{
    if (i == 60)
    {
        //break;//stop
        continue;
    }
    //Console.WriteLine(i);
}

// while
int n;
n = 50;
while (n<=100)
{
    Console.WriteLine(n);

    n = n + 1;
}

// datatypes
// simple: int double bool char
// complex: anything else is complex
int age1;// int age1 simple not expensive,
// you immediately get one int space
//
age1 = 19;//

// complex
string str1;// string complex expensive
// str1
str1 =new string("mis 3033");//

string str2;//
// how many strings do we actually have in the computer memory 
//100